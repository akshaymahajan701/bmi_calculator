import 'package:flutter/material.dart';

const labelstyle = TextStyle(
  color: Color(0xFFFFFFFF),
  fontSize: 25.0,
);

const heightnum=TextStyle(
  color: Color(0xFFFFFFFF),
  fontSize: 45.0,
  fontWeight: FontWeight.bold,
);

const activecardcolor=Color(0xFF1D1E33);

const inactivecardcolor=Color(0xFF111325);