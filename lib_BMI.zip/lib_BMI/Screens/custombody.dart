import 'package:bmicalculator/Screens/result.dart';
import 'package:bmicalculator/constant.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';

enum gender{
    male,
    female,
}

class BackContainer extends StatefulWidget {
  @override
  _BackContainerState createState() => _BackContainerState();
}

class _BackContainerState extends State<BackContainer> {
  @override
  int Slider_height = 180;
  int weight=60;
  int age=21;
  gender selectedgender;
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Expanded(
          child: Row(
            children: <Widget>[
              Expanded(
                child: GestureDetector(
                  onTap: (){
                    setState(() {
                      selectedgender=gender.male;
                    });
                  },
                  child: BackCard(
                    mycolor: selectedgender==gender.male ? inactivecardcolor : activecardcolor,
                    backchild: Container(
                      margin: EdgeInsets.all(15.0),
                      child: Column(
                        children: <Widget>[
                          Icon(
                            FontAwesomeIcons.male,
                            color: Color(0xFFFFFFFF),
                            size: 80.0,
                          ),
                          SizedBox(
                            height: 15.0,
                          ),
                          Text(
                            "MALE",
                            style: labelstyle,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                  child: GestureDetector(
                    onTap: (){
                      setState(() {
                        selectedgender=gender.female;
                      });
                    },
                    child: BackCard(
                mycolor: selectedgender==gender.female ? inactivecardcolor : activecardcolor,
                backchild: Container(
                    margin: EdgeInsets.all(15.0),
                    child: Column(
                      children: <Widget>[
                        Icon(
                          FontAwesomeIcons.female,
                          color: Color(0xFFFFFFFF),
                          size: 80.0,
                        ),
                        SizedBox(
                          height: 15.0,
                        ),
                        Text(
                          "FEMALE",
                          style: labelstyle,
                        ),
                      ],
                    ),
                ),
              ),
                  )),
            ],
          ),
        ),
        Expanded(
          child: BackCard(
            mycolor: inactivecardcolor,
            backchild: Container(
              margin: EdgeInsets.only(top: 10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    "HEIGHT",
                    style: TextStyle(
                      color: Color(0xFFFFFFFF),
                      fontSize: 15.0,
                    ),
                  ),
                  SizedBox(
                    height: 5.0,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: <Widget>[
                      Text(
                        Slider_height.toString(),
                        style: heightnum,
                      ),
                      Text("cm"),
                    ],
                  ),
                  SizedBox(
                    height: 10.0,
                  ),
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      activeTrackColor: Color(0xFFFFFFFF),
                      inactiveTrackColor: Color(0xFF1D1E33),
                      trackHeight: 5.0,
                      overlayColor: Color(0x55FFFFFF),
                      thumbColor: Color(0xFFEB1555),
                    ),
                    child: Slider(
                        min: 120,
                        max: 220,
                        value: Slider_height.toDouble(),
                        onChanged: (newvalue) {
                          setState(() {
                            Slider_height = newvalue.round();
                          });
                        }),
                  ),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: Row(
            children: <Widget>[
              Expanded(
                child: BackCard(
                  mycolor: inactivecardcolor,
                  backchild: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        "WEIGHT",
                        style: TextStyle(
                          color: Color(0xFFFFFFFF),
                          fontSize: 15.0,
                        ),
                      ),
                      SizedBox(
                        height: 5.0,
                      ),
                      Text(
                        weight.toString(),
                        style: heightnum,
                      ),
                      SizedBox(
                        height: 5.0,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          FloatingActionButton(
                            backgroundColor: Color(0x84FFFFFF),
                            onPressed: (){
                              setState(() {
                                weight--;
                              });
                            },
                            child: Icon(
                              FontAwesomeIcons.minus,
                              color: Color(0xFF000000),
                            ),
                            mini: true,
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          FloatingActionButton(
                            backgroundColor: Color(0x84FFFFFF),
                            onPressed: (){
                              setState(() {
                                weight++;
                              });
                            },
                            child: Icon(
                              FontAwesomeIcons.plus,
                              color: Color(0xFF000000),
                            ),
                            mini: true,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: BackCard(
                  mycolor: inactivecardcolor,
                  backchild: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text("AGE",
                    style: TextStyle(
                      color: Color(0xFFFFFFFF),
                      fontSize: 15.0,
                      ),
                      ),
                      SizedBox(height: 5.0,),
                      Text(age.toString(),
                      style: heightnum,
                      ),
                      SizedBox(height: 5.0,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          FloatingActionButton(
                            backgroundColor: Color(0x84FFFFFF),
                            onPressed: (){
                              setState(() {
                                age--;
                              });
                            },
                            child: Icon(
                              FontAwesomeIcons.minus,
                              color: Color(0xFF000000),
                            ),
                            mini: true,
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          FloatingActionButton(
                            backgroundColor: Color(0x84FFFFFF),
                            onPressed: (){
                              setState(() {
                                age++;
                              });
                            },
                            child: Icon(
                              FontAwesomeIcons.plus,
                              color: Color(0xFF000000),
                            ),
                            mini: true,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        FlatButton(
          focusColor: Color(0x84EB1555),
          onPressed: (){
           Navigator.push(context,
           MaterialPageRoute(builder: (context)=>Result()),
           );
          },
          child: Container(
            width: double.infinity,
            height: 50.0,
            color: Color(0xFFEB1555),
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Center(
                child: Text(
                  "CALCULATE",
                  style: GoogleFonts.shadowsIntoLight(
                    letterSpacing: 1.2,
                    fontSize: 29.0,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class BackCard extends StatelessWidget {
  BackCard({this.backchild, this.mycolor});

  final Widget backchild;
  final Color mycolor;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10.0),
      color: mycolor,
      child: backchild,
    );
  }
}
