class Brain{
  int age;
  int weight;
  int height;

  Brain({this.weight,this.age,this.height});

  
}