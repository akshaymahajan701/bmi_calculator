import 'package:bmicalculator/Screens/custombody.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark().copyWith(
        primaryColor: Color(0xFF0A0E21),
        scaffoldBackgroundColor: Color(0xFF0A0E21),
      ),
      home: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            title: Text("BMI CALCULATOR",
            style: TextStyle(
              fontSize: 15.0,
              letterSpacing: 2.0,
            ),
            ),
          ),
          body:BackContainer(),
        ),
      ),
    );
  }
}
